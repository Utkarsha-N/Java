package com.example.assignment4;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class StudentPercentageCalculatorController {
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField calculatedMarksField;
    @FXML
    private TextField totalMarksField;
    @FXML
    private TableView<Student> studentTable;
    @FXML
    private TableColumn<Student, String> fullNameCol;
    @FXML
    private TableColumn<Student, Integer> calculatedMarksCol;
    @FXML
    private TableColumn<Student, Integer> totalMarksCol;
    @FXML
    private TableColumn<Student, Double> percentageCol;

    private final ObservableList<Student> students = FXCollections.observableArrayList();

    public void initialize() {
        fullNameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        calculatedMarksCol.setCellValueFactory(new PropertyValueFactory<>("calculatedMarks"));
        totalMarksCol.setCellValueFactory(new PropertyValueFactory<>("totalMarks"));
        percentageCol.setCellValueFactory(new PropertyValueFactory<>("percentage"));

        studentTable.setItems(students);
    }

    @FXML
    private void addStudent(ActionEvent event) {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        int calculatedMarks = Integer.parseInt(calculatedMarksField.getText());
        int totalMarks = Integer.parseInt(totalMarksField.getText());

        if (calculatedMarks < 0 || calculatedMarks > 500 || totalMarks <= 0 || totalMarks > 500) {
            showError("Invalid data entered");
        } else {
            double percentage = ((double) calculatedMarks / totalMarks) * 100;
            Student student = new Student(firstName, lastName, calculatedMarks, totalMarks, percentage);
            students.add(student);

            // Clear input fields after adding student
            firstNameField.clear();
            lastNameField.clear();
            calculatedMarksField.clear();
            totalMarksField.clear();
        }
    }

    @FXML
    private void deleteStudent(ActionEvent event) {
        Student selectedStudent = studentTable.getSelectionModel().getSelectedItem();
        if (selectedStudent != null) {
            students.remove(selectedStudent);
        } else {
            showError("Please select a student to delete.");
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class Student {
        private final String fullName;
        private final int calculatedMarks;
        private final int totalMarks;
        private final double percentage;

        public Student(String firstName, String lastName, int calculatedMarks, int totalMarks, double percentage) {
            this.fullName = firstName + " " + lastName;
            this.calculatedMarks = calculatedMarks;
            this.totalMarks = totalMarks;
            this.percentage = percentage;
        }

        public String getFullName() {
            return fullName;
        }

        public int getCalculatedMarks() {
            return calculatedMarks;
        }

        public int getTotalMarks() {
            return totalMarks;
        }

        public double getPercentage() {
            return percentage;
        }
    }
}